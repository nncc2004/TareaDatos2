		INSTRUCCIONES

Por comodidad de la lectura, la tarea se separó en 2 archivos diferentes: main.cpp y TDA.h.
El primer archivo es el compilable, mientras que el segundo es un header para el main.cpp
En el header (TDA.h) se tienen todas las funciones del TDA junto con las funciones auxiliares utilizadas para el correcto funcionamiento de la tarea. Ambos archivos deben estar dentro de la misma carpeta para que la tarea funcione. Además, la carpeta tiene que haber sido extraída del .zip para asegurar el comportamiento adecuado de la tarea

Es por esto que para la compilación de la tarea, únicamente se debe compilar main.cpp

La forma de compilación es la vista en clases con g++:
g++ main.cpp -o ejecutable.exe