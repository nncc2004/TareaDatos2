#include<iostream>
#include<string.h>
#include "TDA.h"
#include<fstream>
using namespace std;

int main(){
	super_string s;
	ifstream archivo;
	string lineaActual = "FIN";
	char caracterActual;
	archivo.open("prueba.txt", ios::in);
	archivo>>lineaActual;
	while(lineaActual!="FIN"){
		if (lineaActual == "REVERSO") {
			int l, r;
			archivo>>l;
			archivo>>r;
			super_string R1, R2, R3, R4;
			s.separar(r+1, R1, R2);
			R1.separar(l, R3, R4);
			R4.reverso();
			R4.juntar(R2);
			R3.juntar(R4);
			s.limpiar();
			s.juntar(R3);
        } else if (lineaActual == "ELIMINAR") {
            int l, r;
			archivo>>l;
			archivo>>r;
			super_string E1, E2, E3, E4;
			s.separar(l, E1, E2);
			E2.separar(r-l+1, E3, E4);
			E1.juntar(E4);
			s.limpiar();
			s.juntar(E1);
        } else if (lineaActual == "INSERTAR") {
        	super_string nuevo,I1, I2;
            int i;
            archivo>>i;
            string S;
            archivo>>S;
            for (int k =0; k<S.length(); k++){
			nuevo.agregar(S[k]);
			}
			s.separar(i, I1, I2);
			I1.juntar(nuevo);
			I1.juntar(I2);
			s.limpiar();
			s.juntar(I1);
        } else if (lineaActual == "RECORTAR") {
			cout<<s.recortar()<<"\n";
        } else if (lineaActual == "MOSTRAR") {
            string actual = s.stringizar();
			cout<<actual<<"\n";
        };
		archivo>>lineaActual;
	}
	return 0;
}
