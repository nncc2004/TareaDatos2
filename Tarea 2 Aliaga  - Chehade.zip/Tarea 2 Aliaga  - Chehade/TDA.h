#ifndef TDA
#define TDA
#include<iostream>
#include<string.h>

using namespace std;


//TDA
class super_string {
	private:
		struct nodo {
			nodo *left = nullptr, *right = nullptr;
			int index;
			char c;
			nodo(int index, char c) {} //CONTRSUCTOR!!!!
			nodo(){}
		};
		int height = 0; // Altura del �rbol
		int length = 0; // Largo del super-string
		nodo* root = nullptr; // Ra�z del super-string
	public:
		super_string() {}
		void juntar(super_string &s);
		void agregar(char c);
		void separar(int i, super_string &a, super_string &b);
		void reverso(); 
		int recortar();
		string stringizar(); 
		void limpiar();

		//recortar
		nodo* balanceo(nodo** arreglo, int inicio, int final);
		void InOrdenRecortar(nodo*CurrNodo, nodo** arreglo, int &k);
		int altura(nodo* nodo);		
		//auxiliares
		void InOrdenHelpJuntar1(nodo* nodo, int length);
		void InOrdenHelpJuntar2(nodo* nodo, super_string::nodo* raizS);
		void InOrdenHelpSeparar(nodo* nodo, int i, super_string &a, super_string&b);
		void InOrdenHelpReverso(nodo* nodo, string reversed);
		void InOrdenHelpStringizar(nodo* nodo, string & texto);
		void PostOrdenHelpLimpiar(nodo* nodo);

		
};
//Agregar:
 /*****
 * (1) void agregar
******
 * Crea un nuevo nodo con el caracater ingreado y el largo del arbol como index.
 * Si el arbol est� vac�o, conecta root al nuevo nodo, y si no est� vac�o lo conecta con el nodo m�s a la derecha
 ******
 * Input:
 * char c: caracter en cuesti�n
 * .......
 ******
 * Returns:
 * void, no hay retorno
 *****/
void super_string::agregar(char c){
	//Crear el nodo
	nodo* NuevoNodo = new nodo();
	NuevoNodo->c = c;
	NuevoNodo->index = length;
	//Primero ver si el arbol esta vacio por medio de la raiz
	if(root == nullptr){
		root = NuevoNodo;
		length++;
		return;
	}else{//Aca si el arbol no esta vacio
		nodo* Curr = root; //Como visto en clases para listas, nodo actual para poder recorrer
		//Se recorre el arbolhasta encntrar un espacio vacio como hijo derecho de un nodo y se inserta el nodo.
		while (true) {
            if (Curr->right != nullptr) {
                Curr = Curr->right;
            } else {
                Curr->right = NuevoNodo;
                length++;
                break;
            }
        }
	}
	height = altura(root);
}
//Juntar y auxiliares
 /*****
 * (2) void InOrdenHelpJuntar1
******
 * Funci�n auxiliar 1 para juntar. Recorre InOrden el segundo arbol y aumenta sus �ndices en el largo del arbol original
 ******
 * Input:
 * nodo* nodo: recibe inicialmente la raiz del segundo arbol
 * int length: recibe el largo del arbol original para la suma
 * .......
 ******
 * Returns:
 * void, no hay retorno
 *****/
void super_string::InOrdenHelpJuntar1(nodo* nodo, int length){
	if(nodo == nullptr) return;
	InOrdenHelpJuntar1(nodo->left, length);
	nodo->index = nodo->index + length;
	InOrdenHelpJuntar1(nodo->right, length);
}
 /*****
 * (3) void InOrdenHelpJuntar2
******
 * Funci�n auxiliar 2 para juntar. Recorre InOrden el arbol original y por medio del indice encuentra el nodo de mayor valor
 * Cuando lo encuentra, conecta el puntero derecho a la raiz del segundo arbol, que ya tiene sus indices modificados
 ******
 * Input:
 * nodo* nodo: recibe inicialmente la raiz del arbol original
 * nodo* nodo: recibe la raiz del segundo arbol
 * .......
 ******
 * Returns:
 * void, no hay retorno
 *****/
void super_string::InOrdenHelpJuntar2(nodo* nodo, super_string::nodo* raizS){
	if(nodo == nullptr) return;
	InOrdenHelpJuntar2(nodo->left, raizS);
	if(nodo->index == length-1){
		nodo->right = raizS;
	}
	InOrdenHelpJuntar2(nodo->right, raizS);
}
 /*****
 * (4) void juntar
******
 * Funci�n para juntar un nuevo super_string al actual.
 * si el arbol actual est� vac�o, conecta la raiz a la raiz del nuevo arbol
 * Si no est� vac�o, llama a InOrdenHelpJuntar1 y InOrdenHelpJuntar2
 * Luego modifica length y height a los nuevos valores
 ******
 * Input:
 * super_string &s: recibe el nuevo super string que se quiere a�adir al original. Por referencia para poder modificar los �ndices.
 * .......
 ******
 * Returns:
 * void, no hay retorno
 *****/
void super_string::juntar(super_string &s){
	//Se quiere a�adir s al sstring actual
	//recorrer inorden s e ir agreando al actual los nodos
	if(root == nullptr){
		root = s.root;
	}else{
		InOrdenHelpJuntar1(s.root, length);
		InOrdenHelpJuntar2(root, s.root);
	}
	height = altura(root);
	length = length + s.length;
	
}
//Separar y auxiliar
 /*****
 * (5) void InOrdenHelpSeparar
******
 * Funci�n auxiliar para separar. Recorre InOrden el arbol y seg�n si el �ndice de cada nodo es mayor o menor que i, agrega el caracter de dicho nodo 
 * al arbol correspondiente.
 ******
 * Input:
 * nodo* nodo: recibe inicialmente la raiz del arbol original
 * int i: recibe un entero que marca d�nde se har� la reparaci�n
 *super_string &a: recibe un super_string por referencia para todos los nodos menores que i
  *super_string &b: recibe un super_string por referencia para todos los nodos mayores o iguales que i
 * .......
 ******
 * Returns:
 * void, no hay retorno
 *****/
void super_string::InOrdenHelpSeparar(nodo* nodo, int i, super_string &a, super_string&b){
	if(nodo == nullptr) return;
	InOrdenHelpSeparar(nodo->left, i, a, b);
	if(nodo->index<i) a.agregar(nodo->c);
	else b.agregar(nodo->c);
	InOrdenHelpSeparar(nodo->right, i, a, b);
}
 /*****
 * (6) void separar
******
 * �nicamente llama a InOrdenHelpSeparar
 ******
 * Input:
 * int i: el �ndice donde se quiere la separaci�n
 * super_string &a: recibe un super_string por referencia para todos los nodos menores que i
 * super_string &b: recibe un super_string por referencia para todos los nodos mayores o iguales que i
 * .......
 ******
 * Returns:
 * void, no hay retorno
 *****/
void super_string::separar(int i, super_string &a, super_string&b){
	InOrdenHelpSeparar(root, i, a, b);
}

//reverso
 /*****
 * (7) void InOrdenHelpReverso
******
 * recorre el arbol in orden, y en cada nodo, intercambia el valor de C con el caracter en esa posici�n del string revertido
 ******
 * Input:
 * nodo* nodo: Inicialment recibe la raiz del arbol y luego es recursiva con cada nodo
 * string reversed: Una copia del string de todo el texto pero reverido
 * .......
 ******
 * Returns:
 * void, no hay retorno
 *****/
void super_string::InOrdenHelpReverso(nodo* nodo, string reversed){
	if(nodo == nullptr) return;
	InOrdenHelpReverso(nodo->left, reversed);
	nodo->c = reversed[nodo->index];
	InOrdenHelpReverso(nodo->right, reversed);
}
 /*****
 * (8) void reverso
******
 * Primero stringiza el arbol para obtener todo el texto y luego lo da vuelta en una nueva varibale string.
 * Luego llama a la funci�n InOrdenHelpReversed con los par�metros hablados.
 ******
 * Input:
 * No tiene inputs
 * .......
 ******
 * Returns:
 * void, no hay retorno
 *****/
void super_string::reverso(){
	string texto, reversed;
	texto = stringizar();
	for(int k = texto.length()-1; k>=0; k--){
		reversed += texto[k];
	}
	InOrdenHelpReverso(root, reversed);
}

//recortar
 /*****
 * (9) nodo* balanceo 
******
 * primero verifica que los numeros de inicio y final sean v�lidos y que este sea nuestro termino de la recursividad
 * Define mitad, que corresponde al puntero de nodo que est� en el medio del arreglo con divisi�n entera por si es par.
 * con eso, define una nueva ra�z, desde la cual inicia nuevamente la recursividad por el lado izquierdo y derecho por separado
 * De esta manera, al ser la lista una lista ordenada, el arbol se va a ir balancenado sin tener que hacer rotaciones
 ******
 * Input:
 * nodo** arreglo: es un arreglo de punteros de nodos. 
 * int inicio: es un entero que marca la posici�n de inicio del arreglo dado
 int final: es un enetero que marca la posici�n final del arreglo dado
 * .......
 ******
 * Returns:
 * retorna un puntero tipo nodo apuntando a la ra�z del nuevo arbol balanceado.
 *****/
super_string::nodo* super_string::balanceo(nodo** arreglo, int inicio, int final){
	if(inicio > final) return nullptr;
	
	int mitad = (inicio + final)/2;
	nodo* raiz = arreglo[mitad];
	raiz->left = balanceo(arreglo, inicio, mitad-1);
	raiz->right = balanceo(arreglo, mitad+1, final);
	return raiz;
}

 /*****
 * (10) void InOrdenRecortar
******
 * Recorre InOrden el arbol actual para ir a�adiendo a la lista de punteros, la posici�n de cada uno de los nodos del arbol
 ******
 * Input:
 * nodo * nodo: recibe inicialmente la raiz del arbol para hacer el recorrido 
 * nodo ** arreglo: Recbie la lista inicialmente vac�a para ir almacenando los punteros.
 * int k: recibe un entero que se usar� como posici�n en la lista para cada iteraci�n de la funci�n
 * .......
 ******
 * Returns:
 * void, no hay retorno
 *****/
void super_string::InOrdenRecortar(nodo*CurrNodo, nodo**arreglo, int &k){
	if(CurrNodo == nullptr) return;
	InOrdenRecortar(CurrNodo->left, arreglo, k);
	arreglo[k] = CurrNodo;
	k++;
	InOrdenRecortar(CurrNodo->right, arreglo, k);
}

 /*****
 * (11) void recortar
******
 * Crea un arreglo de punteros de tipo nodo del largo del length del �rbol. Se define la variable largo porque causaba errores poner directamente length, no s� por qu�.
 * se llama a la funci�n InOrdenRecortar con los par�metros correspondientes para llenar la lista con los punteros
 * luego se llama a la funci�n balanceo con los par�metros para hacer el arbol balanceado
 * Se reasigna la raiz del arbol al retorno de la funci�n y luego se actualiza la altura del arbol con la funci�n altura
 * La justificaci�n de por qu� esta funci�n recorta el tiempo de ejecuci�n a O(logn) es porque porque equilibra el arbol, optimizando 
 * la cantidad m�xima de busquedas para encontrar un nodo. 
 ******
 * Input:
 * No tiene inputs
 * .......
 ******
 * Returns:
 * retorna un entero con el valor de la nueva altura del arbol.
 *****/
int super_string::recortar(){
	int largo = length;
	nodo** arreglo = new nodo*[largo];
	int k = 0;
	InOrdenRecortar(root, arreglo, k);
	nodo* NuevaRaiz = balanceo(arreglo, 0 , largo-1);
	root =  NuevaRaiz;
	height = altura(root);
	return height;
}
//stringizar
 /*****
 * (12) void InOrdenHelpStringizar
******
 * Recorre InOrden el �rbol y concatena el valor de C de cada nodo al string
 ******
 * Input:
 * nodo* nodo: recibe inicialmente la raiz del arbol para recorrerlo InOrden
 * string &texto: reicibe un string por referencia inicialmente vac�o para ir concatenando los caracteres
 * .......
 ******
 * Returns:
 * void, no hay retorno
 *****/
void super_string::InOrdenHelpStringizar(nodo* nodo, string & texto){
	if(nodo == nullptr) return;
	InOrdenHelpStringizar(nodo->left, texto);
	texto += nodo->c;
	InOrdenHelpStringizar(nodo->right, texto);
}
 /*****
 * (13) string stringizar
******
 * crea un string vac�o y llama a la funci�n InOrdenHelpStringizar
 ******
 * Input:
 * No hay inputs
 * .......
 ******
 * Returns:
 * retorna un string con el texto del �rbol.
 *****/
string super_string::stringizar(){
	string texto;
	InOrdenHelpStringizar(root, texto);
	return texto;
}

//limpiar
 /*****
 * (14) void PostOrdenHelpLimpiar
******
 * Recorre en PostOrden el �rbol y va borrando los nodos
 ******
 * Input:
 * nodo* nodo: recibe inicialmente la raiz del arbol para recorrerlo en PostOrden
 * .......
 ******
 * Returns:
 * void, no hay retorno
 *****/
void super_string::PostOrdenHelpLimpiar(nodo* nodo) {
    if (nodo == nullptr) return;
    PostOrdenHelpLimpiar(nodo->left);
    PostOrdenHelpLimpiar(nodo->right);
    delete nodo;
}
 /*****
 * (15) void limpiar
******
 * Llama a la funci�n PostOrdenHelpLimpiar con los par�metros que corresponde
 * luego reinicia los valores de root, length y height del TDA
 ******
 * Input:
 * no recibe inputs
 * .......
 ******
 * Returns:
 * void, no hay retorno
 *****/
void super_string::limpiar(){
	PostOrdenHelpLimpiar(root);
	root = nullptr;
	length = 0;
	height = 0;
}

//Altura
 /*****
 * (16) int altura
******
 * Recorre recursivamente el arbol separando por izquierda y derecha y va aumentando la variable altura seg�n qu� altura es mayor con cada iteraci�n
 ******
 * Input:
 * nodo* nodo: recibe inicialmente la raiz del arbol para recorrerlo
 * .......
 ******
 * Returns:
 * retorna un entero con la altura m�xima del arbol.
 *****/
int super_string::altura(nodo*nodo){
	int Altura = 0;
	if(nodo == nullptr) 
	{
		return 0;
	}
	else
	{
		int altura_subarbol_izq = altura(nodo->left); //recursivamente se va aumentando la altura cada vez que de itera sobre a parte izquierda del arbol
		int altura_subarbol_der = altura(nodo->right); //lo mismo pero a la derecha
		if(altura_subarbol_izq>altura_subarbol_der)
		{
			Altura = 1 + altura_subarbol_izq;
		}
		else
		{
			Altura = 1 + altura_subarbol_der;
		}
	}
	return Altura;
}
#endif
